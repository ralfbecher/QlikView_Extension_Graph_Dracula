QlikView_Extension_Graph_Dracula
================================

Graph Visualization Extension Object for QlikView based on Graph Dracula JavaScript Library